# Nova IPTV Manager

Proyecto Flutter listo para crear una APK con GitHub Actions.

## Archivos indispensables

- `lib/main.dart`
- `pubspec.yaml`
- `.github/workflows/crear-apk.yml`

## Compilar desde el celular

1. Sube el contenido de esta carpeta a la raíz del repositorio.
2. Abre **Actions**.
3. Selecciona **Crear APK Android**.
4. Pulsa **Run workflow**.
5. Cuando termine, descarga `Nova-IPTV-Manager-APK`.
6. Extrae el ZIP e instala `app-release.apk`.
