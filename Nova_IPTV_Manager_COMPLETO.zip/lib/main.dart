import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  runApp(const NovaApp());
}

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF00E5FF);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Nova IPTV Manager',
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
          surface: const Color(0xFF111827),
        ),
        scaffoldBackgroundColor: const Color(0xFF070B14),
        cardTheme: CardThemeData(
          elevation: 0,
          color: const Color(0xFF111827),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: Color(0x2222D3EE)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0D1422),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0x2238BDF8)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: seed, width: 1.5),
          ),
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xFF0B1220),
          indicatorColor: Color(0x3338BDF8),
          height: 72,
        ),
      ),
      home: const HomeShell(),
    );
  }
}

class AppDatabase {
  AppDatabase._();
  static final instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final path = join(await getDatabasesPath(), 'nova_iptv.db');
    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE clients(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            plan TEXT,
            creditCost REAL NOT NULL,
            advertisingCost REAL NOT NULL,
            margin REAL NOT NULL,
            includeAdvertising INTEGER NOT NULL,
            includeIva INTEGER NOT NULL,
            ivaPercent REAL NOT NULL,
            price REAL NOT NULL,
            dueDate TEXT NOT NULL,
            status TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            clientId INTEGER,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            method TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            description TEXT NOT NULL,
            amount REAL NOT NULL,
            date TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<List<Map<String, Object?>>> clients() async {
    final db = await database;
    return db.query('clients', orderBy: 'dueDate ASC');
  }

  Future<int> addClient(Map<String, Object?> data) async {
    final db = await database;
    return db.insert('clients', data);
  }

  Future<int> updateClient(int id, Map<String, Object?> data) async {
    final db = await database;
    return db.update('clients', data, where: 'id=?', whereArgs: [id]);
  }

  Future<int> deleteClient(int id) async {
    final db = await database;
    await db.delete('payments', where: 'clientId=?', whereArgs: [id]);
    return db.delete('clients', where: 'id=?', whereArgs: [id]);
  }

  Future<List<Map<String, Object?>>> payments() async {
    final db = await database;
    return db.rawQuery('''
      SELECT payments.*, clients.name AS clientName
      FROM payments
      LEFT JOIN clients ON clients.id = payments.clientId
      ORDER BY payments.date DESC, payments.id DESC
    ''');
  }

  Future<int> addPayment(Map<String, Object?> data) async {
    final db = await database;
    return db.insert('payments', data);
  }

  Future<List<Map<String, Object?>>> expenses() async {
    final db = await database;
    return db.query('expenses', orderBy: 'date DESC, id DESC');
  }

  Future<int> addExpense(Map<String, Object?> data) async {
    final db = await database;
    return db.insert('expenses', data);
  }
}

String money(num value) =>
    NumberFormat.currency(locale: 'es_CL', symbol: r'$', decimalDigits: 0)
        .format(value);

double asDouble(Object? value) => (value as num?)?.toDouble() ?? 0;
int asInt(Object? value) => (value as num?)?.toInt() ?? 0;

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  int refreshKey = 0;

  void refresh() => setState(() => refreshKey++);

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(key: ValueKey('d$refreshKey')),
      ClientsPage(key: ValueKey('c$refreshKey'), onChanged: refresh),
      FinancePage(key: ValueKey('f$refreshKey'), onChanged: refresh),
      RemindersPage(key: ValueKey('r$refreshKey')),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Panel'),
          NavigationDestination(icon: Icon(Icons.people_alt_rounded), label: 'Clientes'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_rounded), label: 'Finanzas'),
          NavigationDestination(icon: Icon(Icons.notifications_active_rounded), label: 'Avisos'),
        ],
      ),
    );
  }
}

class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget? action;
  const PageHeader({super.key, required this.title, required this.subtitle, this.action});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(colors: [Color(0xFF00E5FF), Color(0xFF7C3AED)]),
          boxShadow: const [BoxShadow(color: Color(0x4400E5FF), blurRadius: 24)],
        ),
        child: const Icon(Icons.bolt_rounded, color: Colors.white),
      ),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white60)),
      ])),
      if (action != null) action!,
    ]);
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  Future<Map<String, dynamic>> load() async {
    final clients = await AppDatabase.instance.clients();
    final payments = await AppDatabase.instance.payments();
    final expenses = await AppDatabase.instance.expenses();
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final active = clients.where((e) => e['status'] == 'Activo').length;
    final overdue = clients.where((e) {
      final due = DateTime.tryParse('${e['dueDate']}');
      return e['status'] == 'Activo' && due != null && due.isBefore(today);
    }).length;
    final soon = clients.where((e) {
      final due = DateTime.tryParse('${e['dueDate']}');
      if (due == null || e['status'] != 'Activo') return false;
      final days = due.difference(today).inDays;
      return days >= 0 && days <= 7;
    }).length;
    final income = payments.fold<double>(0, (s, e) => s + asDouble(e['amount']));
    final expense = expenses.fold<double>(0, (s, e) => s + asDouble(e['amount']));
    return {
      'clients': clients,
      'active': active,
      'overdue': overdue,
      'soon': soon,
      'income': income,
      'expense': expense,
      'profit': income - expense,
    };
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: load(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final data = snapshot.data!;
        final clients = data['clients'] as List<Map<String, Object?>>;
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          children: [
            const PageHeader(title: 'Nova Control', subtitle: 'Tu negocio en tiempo real'),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0E7490), Color(0xFF312E81)],
                ),
                boxShadow: const [BoxShadow(color: Color(0x3300E5FF), blurRadius: 28, offset: Offset(0, 14))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('UTILIDAD TOTAL', style: TextStyle(color: Colors.white70, letterSpacing: 1.6, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                Text(money(data['profit']), style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900)),
                const SizedBox(height: 18),
                Row(children: [
                  Expanded(child: MiniValue(icon: Icons.south_west_rounded, label: 'Ingresos', value: money(data['income']))),
                  const SizedBox(width: 10),
                  Expanded(child: MiniValue(icon: Icons.north_east_rounded, label: 'Gastos', value: money(data['expense']))),
                ]),
              ]),
            ),
            const SizedBox(height: 18),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: .88,
              children: [
                MetricCard(icon: Icons.verified_user_rounded, label: 'Activos', value: '${data['active']}', accent: const Color(0xFF34D399)),
                MetricCard(icon: Icons.schedule_rounded, label: 'Por vencer', value: '${data['soon']}', accent: const Color(0xFFFBBF24)),
                MetricCard(icon: Icons.error_outline_rounded, label: 'Vencidos', value: '${data['overdue']}', accent: const Color(0xFFFB7185)),
              ],
            ),
            const SizedBox(height: 22),
            Text('Próximos vencimientos', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (clients.isEmpty)
              const EmptyCard(icon: Icons.person_add_alt_1_rounded, text: 'Agrega tu primer cliente para comenzar.')
            else
              ...clients.take(5).map((client) => ClientTile(client: client)),
          ],
        );
      },
    );
  }
}

class MiniValue extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const MiniValue({super.key, required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(18)),
      child: Row(children: [
        Icon(icon, size: 20, color: Colors.white70),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.white60)),
          Text(value, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
        ])),
      ]),
    );
  }
}

class MetricCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color accent;
  const MetricCard({super.key, required this.icon, required this.label, required this.value, required this.accent});
  @override
  Widget build(BuildContext context) {
    return Card(child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 38, height: 38, decoration: BoxDecoration(color: accent.withOpacity(.15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: accent, size: 21)),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Colors.white60)),
      ]),
    ));
  }
}

class ClientsPage extends StatefulWidget {
  final VoidCallback onChanged;
  const ClientsPage({super.key, required this.onChanged});
  @override
  State<ClientsPage> createState() => _ClientsPageState();
}

class _ClientsPageState extends State<ClientsPage> {
  String search = '';

  Future<void> openForm([Map<String, Object?>? client]) async {
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0B1220),
      builder: (_) => ClientForm(client: client),
    );
    if (changed == true) {
      setState(() {});
      widget.onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, Object?>>>(
      future: AppDatabase.instance.clients(),
      builder: (context, snapshot) {
        final all = snapshot.data ?? [];
        final clients = all.where((e) {
          final q = search.toLowerCase();
          return '${e['name']}'.toLowerCase().contains(q) ||
              '${e['phone']}'.toLowerCase().contains(q) ||
              '${e['plan']}'.toLowerCase().contains(q);
        }).toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          children: [
            PageHeader(
              title: 'Clientes',
              subtitle: '${all.length} registros',
              action: IconButton.filled(onPressed: () => openForm(), icon: const Icon(Icons.add_rounded)),
            ),
            const SizedBox(height: 18),
            TextField(
              onChanged: (value) => setState(() => search = value),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Buscar cliente, teléfono o plan'),
            ),
            const SizedBox(height: 14),
            if (!snapshot.hasData)
              const Center(child: CircularProgressIndicator())
            else if (clients.isEmpty)
              const EmptyCard(icon: Icons.groups_2_rounded, text: 'No hay clientes que mostrar.')
            else
              ...clients.map((client) => GestureDetector(onTap: () => openForm(client), child: ClientTile(client: client))),
          ],
        );
      },
    );
  }
}

class ClientTile extends StatelessWidget {
  final Map<String, Object?> client;
  const ClientTile({super.key, required this.client});

  @override
  Widget build(BuildContext context) {
    final due = DateTime.tryParse('${client['dueDate']}') ?? DateTime.now();
    final now = DateTime.now();
    final days = due.difference(DateTime(now.year, now.month, now.day)).inDays;
    final overdue = days < 0;
    final soon = days >= 0 && days <= 7;
    final color = overdue ? const Color(0xFFFB7185) : soon ? const Color(0xFFFBBF24) : const Color(0xFF34D399);
    final status = overdue ? 'Vencido hace ${days.abs()} días' : days == 0 ? 'Vence hoy' : 'Vence en $days días';

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: color.withOpacity(.15),
            child: Text('${client['name']}'.isEmpty ? '?' : '${client['name']}'[0].toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${client['name']}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text('${client['plan']} · ${money(asDouble(client['price']))}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 5),
            Text(status, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12)),
          ])),
          const Icon(Icons.chevron_right_rounded, color: Colors.white38),
        ]),
      ),
    );
  }
}

class ClientForm extends StatefulWidget {
  final Map<String, Object?>? client;
  const ClientForm({super.key, this.client});
  @override
  State<ClientForm> createState() => _ClientFormState();
}

class _ClientFormState extends State<ClientForm> {
  final formKey = GlobalKey<FormState>();
  late final TextEditingController name;
  late final TextEditingController phone;
  late final TextEditingController plan;
  late final TextEditingController credit;
  late final TextEditingController advertising;
  late final TextEditingController margin;
  late final TextEditingController iva;
  bool includeAdvertising = true;
  bool includeIva = true;
  DateTime dueDate = DateTime.now().add(const Duration(days: 30));

  @override
  void initState() {
    super.initState();
    final c = widget.client;
    name = TextEditingController(text: '${c?['name'] ?? ''}');
    phone = TextEditingController(text: '${c?['phone'] ?? ''}');
    plan = TextEditingController(text: '${c?['plan'] ?? 'Plan mensual'}');
    credit = TextEditingController(text: '${c?['creditCost'] ?? 0}');
    advertising = TextEditingController(text: '${c?['advertisingCost'] ?? 0}');
    margin = TextEditingController(text: '${c?['margin'] ?? 0}');
    iva = TextEditingController(text: '${c?['ivaPercent'] ?? 19}');
    includeAdvertising = asInt(c?['includeAdvertising'] ?? 1) == 1;
    includeIva = asInt(c?['includeIva'] ?? 1) == 1;
    dueDate = DateTime.tryParse('${c?['dueDate'] ?? ''}') ?? DateTime.now().add(const Duration(days: 30));
  }

  double get price {
    final base = (double.tryParse(credit.text) ?? 0) +
        (includeAdvertising ? (double.tryParse(advertising.text) ?? 0) : 0) +
        (double.tryParse(margin.text) ?? 0);
    return includeIva ? base * (1 + (double.tryParse(iva.text) ?? 0) / 100) : base;
  }

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    final data = <String, Object?>{
      'name': name.text.trim(),
      'phone': phone.text.trim(),
      'plan': plan.text.trim(),
      'creditCost': double.tryParse(credit.text) ?? 0,
      'advertisingCost': double.tryParse(advertising.text) ?? 0,
      'margin': double.tryParse(margin.text) ?? 0,
      'includeAdvertising': includeAdvertising ? 1 : 0,
      'includeIva': includeIva ? 1 : 0,
      'ivaPercent': double.tryParse(iva.text) ?? 0,
      'price': price,
      'dueDate': DateFormat('yyyy-MM-dd').format(dueDate),
      'status': 'Activo',
    };
    if (widget.client == null) {
      await AppDatabase.instance.addClient(data);
    } else {
      await AppDatabase.instance.updateClient(asInt(widget.client!['id']), data);
    }
    if (mounted) Navigator.pop(context, true);
  }

  Future<void> delete() async {
    if (widget.client == null) return;
    await AppDatabase.instance.deleteClient(asInt(widget.client!['id']));
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 48, height: 5, margin: const EdgeInsets.only(bottom: 18), decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20))),
            Text(widget.client == null ? 'Nuevo cliente' : 'Editar cliente', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            TextFormField(
              controller: name,
              decoration: const InputDecoration(labelText: 'Nombre', prefixIcon: Icon(Icons.person_rounded)),
              validator: (value) => value == null || value.trim().isEmpty ? 'Obligatorio' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Teléfono con código de país', prefixIcon: Icon(Icons.phone_rounded))),
            const SizedBox(height: 12),
            TextFormField(controller: plan, decoration: const InputDecoration(labelText: 'Plan o servicio', prefixIcon: Icon(Icons.live_tv_rounded))),
            const SizedBox(height: 16),
            const Text('Cálculo del valor', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: NumberField(controller: credit, label: 'Crédito', onChanged: () => setState(() {}))),
              const SizedBox(width: 10),
              Expanded(child: NumberField(controller: advertising, label: 'Publicidad', onChanged: () => setState(() {}))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: NumberField(controller: margin, label: 'Ganancia', onChanged: () => setState(() {}))),
              const SizedBox(width: 10),
              Expanded(child: NumberField(controller: iva, label: 'IVA %', onChanged: () => setState(() {}))),
            ]),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Incluir publicidad'), value: includeAdvertising, onChanged: (v) => setState(() => includeAdvertising = v)),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Incluir IVA'), value: includeIva, onChanged: (v) => setState(() => includeIva = v)),
            InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () async {
                final selected = await showDatePicker(context: context, initialDate: dueDate, firstDate: DateTime(2024), lastDate: DateTime(2035));
                if (selected != null) setState(() => dueDate = selected);
              },
              child: InputDecorator(
                decoration: const InputDecoration(labelText: 'Fecha de vencimiento', prefixIcon: Icon(Icons.event_rounded)),
                child: Text(DateFormat('dd/MM/yyyy').format(dueDate)),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF155E75), Color(0xFF3730A3)])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('PRECIO FINAL', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.4)),
                const SizedBox(height: 4),
                Text(money(price), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              ]),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: save, icon: const Icon(Icons.save_rounded), label: Text(widget.client == null ? 'Guardar cliente' : 'Guardar cambios'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
            if (widget.client != null) ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(onPressed: delete, icon: const Icon(Icons.delete_outline_rounded), label: const Text('Eliminar cliente'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50), foregroundColor: const Color(0xFFFB7185))),
            ],
          ]),
        ),
      ),
    );
  }
}

class NumberField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final VoidCallback? onChanged;
  const NumberField({super.key, required this.controller, required this.label, this.onChanged});
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (_) => onChanged?.call(),
      decoration: InputDecoration(labelText: label),
    );
  }
}

class FinancePage extends StatefulWidget {
  final VoidCallback onChanged;
  const FinancePage({super.key, required this.onChanged});
  @override
  State<FinancePage> createState() => _FinancePageState();
}

class _FinancePageState extends State<FinancePage> {
  int tab = 0;

  Future<void> addPayment() async {
    final clients = await AppDatabase.instance.clients();
    if (!mounted) return;
    if (clients.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Primero agrega un cliente.')));
      return;
    }
    final changed = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, backgroundColor: const Color(0xFF0B1220), builder: (_) => PaymentForm(clients: clients));
    if (changed == true) {
      setState(() {});
      widget.onChanged();
    }
  }

  Future<void> addExpense() async {
    final changed = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, backgroundColor: const Color(0xFF0B1220), builder: (_) => const ExpenseForm());
    if (changed == true) {
      setState(() {});
      widget.onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, Object?>>>(
      future: tab == 0 ? AppDatabase.instance.payments() : AppDatabase.instance.expenses(),
      builder: (context, snapshot) {
        final rows = snapshot.data ?? [];
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          children: [
            PageHeader(title: 'Finanzas', subtitle: 'Control de entradas y salidas', action: IconButton.filled(onPressed: tab == 0 ? addPayment : addExpense, icon: const Icon(Icons.add_rounded))),
            const SizedBox(height: 18),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Cobros'), icon: Icon(Icons.payments_rounded)),
                ButtonSegment(value: 1, label: Text('Gastos'), icon: Icon(Icons.receipt_long_rounded)),
              ],
              selected: {tab},
              onSelectionChanged: (value) => setState(() => tab = value.first),
            ),
            const SizedBox(height: 16),
            if (!snapshot.hasData)
              const Center(child: CircularProgressIndicator())
            else if (rows.isEmpty)
              EmptyCard(icon: tab == 0 ? Icons.payments_outlined : Icons.receipt_long_outlined, text: tab == 0 ? 'Todavía no registraste cobros.' : 'Todavía no registraste gastos.')
            else
              ...rows.map((row) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: (tab == 0 ? const Color(0xFF34D399) : const Color(0xFFFB7185)).withOpacity(.15),
                    child: Icon(tab == 0 ? Icons.south_west_rounded : Icons.north_east_rounded, color: tab == 0 ? const Color(0xFF34D399) : const Color(0xFFFB7185)),
                  ),
                  title: Text(tab == 0 ? '${row['clientName'] ?? 'Cliente'}' : '${row['description']}'),
                  subtitle: Text(tab == 0 ? '${row['method']} · ${row['date']}' : '${row['category']} · ${row['date']}'),
                  trailing: Text(money(asDouble(row['amount'])), style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
              )),
          ],
        );
      },
    );
  }
}

class PaymentForm extends StatefulWidget {
  final List<Map<String, Object?>> clients;
  const PaymentForm({super.key, required this.clients});
  @override
  State<PaymentForm> createState() => _PaymentFormState();
}

class _PaymentFormState extends State<PaymentForm> {
  late Map<String, Object?> client;
  late final TextEditingController amount;
  String method = 'Transferencia';
  int renewalDays = 30;

  @override
  void initState() {
    super.initState();
    client = widget.clients.first;
    amount = TextEditingController(text: '${client['price']}');
  }

  Future<void> save() async {
    final now = DateTime.now();
    await AppDatabase.instance.addPayment({
      'clientId': client['id'],
      'amount': double.tryParse(amount.text) ?? 0,
      'date': DateFormat('yyyy-MM-dd').format(now),
      'method': method,
    });
    final currentDue = DateTime.tryParse('${client['dueDate']}') ?? now;
    final base = currentDue.isAfter(now) ? currentDue : now;
    await AppDatabase.instance.updateClient(asInt(client['id']), {
      'dueDate': DateFormat('yyyy-MM-dd').format(base.add(Duration(days: renewalDays))),
      'status': 'Activo',
    });
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Sheet(
      title: 'Registrar cobro',
      children: [
        DropdownButtonFormField<Map<String, Object?>>(
          value: client,
          decoration: const InputDecoration(labelText: 'Cliente'),
          items: widget.clients.map((e) => DropdownMenuItem(value: e, child: Text('${e['name']}'))).toList(),
          onChanged: (value) {
            if (value == null) return;
            setState(() {
              client = value;
              amount.text = '${value['price']}';
            });
          },
        ),
        const SizedBox(height: 12),
        NumberField(controller: amount, label: 'Monto recibido'),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: method,
          decoration: const InputDecoration(labelText: 'Método'),
          items: ['Transferencia', 'Efectivo', 'Tarjeta', 'Otro'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (value) => setState(() => method = value ?? method),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          value: renewalDays,
          decoration: const InputDecoration(labelText: 'Renovar por'),
          items: const [
            DropdownMenuItem(value: 7, child: Text('7 días')),
            DropdownMenuItem(value: 15, child: Text('15 días')),
            DropdownMenuItem(value: 30, child: Text('30 días')),
            DropdownMenuItem(value: 60, child: Text('60 días')),
            DropdownMenuItem(value: 90, child: Text('90 días')),
          ],
          onChanged: (value) => setState(() => renewalDays = value ?? renewalDays),
        ),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: save, icon: const Icon(Icons.check_circle_rounded), label: const Text('Registrar y renovar'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
      ],
    );
  }
}

class ExpenseForm extends StatefulWidget {
  const ExpenseForm({super.key});
  @override
  State<ExpenseForm> createState() => _ExpenseFormState();
}

class _ExpenseFormState extends State<ExpenseForm> {
  final description = TextEditingController();
  final amount = TextEditingController();
  String category = 'Créditos IPTV';

  Future<void> save() async {
    if (description.text.trim().isEmpty) return;
    await AppDatabase.instance.addExpense({
      'category': category,
      'description': description.text.trim(),
      'amount': double.tryParse(amount.text) ?? 0,
      'date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
    });
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Sheet(
      title: 'Registrar gasto',
      children: [
        DropdownButtonFormField<String>(
          value: category,
          decoration: const InputDecoration(labelText: 'Categoría'),
          items: ['Créditos IPTV', 'Publicidad', 'Internet', 'Impuestos', 'Herramientas', 'Otros'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (value) => setState(() => category = value ?? category),
        ),
        const SizedBox(height: 12),
        TextField(controller: description, decoration: const InputDecoration(labelText: 'Descripción')),
        const SizedBox(height: 12),
        NumberField(controller: amount, label: 'Monto'),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: save, icon: const Icon(Icons.save_rounded), label: const Text('Guardar gasto'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
      ],
    );
  }
}

class Sheet extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const Sheet({super.key, required this.title, required this.children});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 48, height: 5, margin: const EdgeInsets.only(bottom: 18), decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20))),
          Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          ...children,
        ]),
      ),
    );
  }
}

class RemindersPage extends StatelessWidget {
  const RemindersPage({super.key});

  Future<void> sendWhatsApp(BuildContext context, Map<String, Object?> client) async {
    final phone = '${client['phone']}'.replaceAll(RegExp(r'[^0-9]'), '');
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Este cliente no tiene teléfono.')));
      return;
    }
    final due = DateTime.tryParse('${client['dueDate']}') ?? DateTime.now();
    final text = 'Hola ${client['name']}, te recordamos que tu servicio vence el ${DateFormat('dd/MM/yyyy').format(due)}. El valor de renovación es ${money(asDouble(client['price']))}. Gracias.';
    final uri = Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(text)}');
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No fue posible abrir WhatsApp.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, Object?>>>(
      future: AppDatabase.instance.clients(),
      builder: (context, snapshot) {
        final now = DateTime.now();
        final clients = (snapshot.data ?? []).where((e) {
          final due = DateTime.tryParse('${e['dueDate']}');
          if (due == null || e['status'] != 'Activo') return false;
          return due.difference(DateTime(now.year, now.month, now.day)).inDays <= 7;
        }).toList();

        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          children: [
            const PageHeader(title: 'Recordatorios', subtitle: 'Vencidos y próximos 7 días'),
            const SizedBox(height: 18),
            if (!snapshot.hasData)
              const Center(child: CircularProgressIndicator())
            else if (clients.isEmpty)
              const EmptyCard(icon: Icons.notifications_none_rounded, text: 'No hay avisos pendientes.')
            else
              ...clients.map((client) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    ClientTile(client: client),
                    const SizedBox(height: 4),
                    FilledButton.icon(onPressed: () => sendWhatsApp(context, client), icon: const Icon(Icons.send_rounded), label: const Text('Enviar por WhatsApp'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48))),
                  ]),
                ),
              )),
          ],
        );
      },
    );
  }
}

class EmptyCard extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyCard({super.key, required this.icon, required this.text});
  @override
  Widget build(BuildContext context) {
    return Card(child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 38, horizontal: 20),
      child: Column(children: [
        Icon(icon, size: 46, color: Colors.white30),
        const SizedBox(height: 12),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
      ]),
    ));
  }
}
